# FIFA World Cup Winner Prediction — Monte Carlo Simulation

A Python project that predicts each team's probability of winning a 32-team FIFA World Cup knockout bracket, using a **Poisson goal model** driven by FIFA ranking points and a **Monte Carlo simulation** (thousands of simulated tournaments) to convert match-level probabilities into overall championship odds.

## How It Works

1. **Team strength** — each of the 32 teams is assigned a rating based on (approximate) FIFA World Ranking points.
2. **Match simulation** — for any given match, each team's expected goals (Poisson rate `λ`) are derived from the ranking-point difference between the two sides:
   ```
   λ_A = base_goals * exp((rating_A - rating_B) / rating_scale)
   λ_B = base_goals * exp((rating_B - rating_A) / rating_scale)
   ```
   Goals are then drawn from `Poisson(λ_A)` and `Poisson(λ_B)`. Draws are resolved via extra time/penalties, modeled as a near coin-flip slightly favoring the higher-rated side.
3. **Bracket seeding** — teams are seeded 1-vs-32, 2-vs-31, etc. (highest-rated teams kept apart as long as possible), mirroring real World Cup seeding.
4. **Monte Carlo simulation** — the full 32-team single-elimination bracket (Round of 32 → Round of 16 → QF → SF → Final) is simulated **20,000 times**. The champion is tallied each run, and win probability = (times team won) / (total simulations).

## Results

![Win Probabilities](results/win_probabilities.png)

| Rank | Team | Win Probability |
|---|---|---|
| 1 | Argentina | 18.7% |
| 2 | France | 17.3% |
| 3 | Spain | 16.7% |
| 4 | England | 7.4% |
| 5 | Belgium | 5.1% |
| 6 | Portugal | 4.5% |
| 7 | Germany | 4.5% |
| 8 | Netherlands | 4.2% |
| 9 | Brazil | 4.1% |
| 10 | Morocco | 3.9% |

Full results for all 32 teams are in [`results/win_probabilities.csv`](results/win_probabilities.csv).

## Project Structure

```
├── world_cup_predictor.py       # Main model + Monte Carlo simulation
├── data/
│   └── teams.csv                 # Team ratings dataset
└── results/
    ├── win_probabilities.png     # Bar chart of top contenders
    └── win_probabilities.csv     # Full win-probability table (all 32 teams)
```

## Requirements

```bash
pip install numpy pandas matplotlib
```

## Usage

```bash
python world_cup_predictor.py
```

This will print the top 10 predicted winners to the console and regenerate the chart/CSV in `results/`.

## Notes & Limitations

- Team ratings are **approximate and illustrative**, based on published FIFA ranking points; ranks 21–32 are estimated for demonstration purposes and are not official values.
- The model uses a simplified single-elimination bracket rather than the real group-stage-plus-knockout format, and does not account for injuries, squad form, home advantage, or fixture congestion.
- This is an educational/statistical modeling project, not a betting tool.

## Author

*Swarnakamal Das*
