"""
FIFA World Cup Winner Prediction — Monte Carlo Simulation
==========================================================
Predicts the probability of each team winning a 32-team single-elimination
World Cup bracket using:
  1. A Poisson goal model, where each team's expected goals are derived
     from the FIFA ranking-point difference between the two sides.
  2. Monte Carlo simulation (thousands of full-bracket run-throughs) to
     convert single-match probabilities into overall tournament win odds.

Data source: FIFA Men's World Ranking points (approximate, illustrative —
see data/teams.csv). Ranks 21-32 are estimated for demo purposes since
official points for those positions were not available at time of writing.

Usage:
    python world_cup_predictor.py
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

RNG = np.random.default_rng(42)

BASE_GOALS = 1.35     # average goals scored per team per World Cup match
RATING_SCALE = 300.0  # controls how strongly rating gap affects expected goals
N_SIMULATIONS = 20000


def load_teams(path="data/teams.csv"):
    df = pd.read_csv(path)
    df = df.sort_values("rating", ascending=False).reset_index(drop=True)
    return df


def expected_goals(rating_a, rating_b):
    """Poisson expected-goal rates for two opposing teams based on rating gap."""
    diff = rating_a - rating_b
    lam_a = BASE_GOALS * np.exp(diff / RATING_SCALE)
    lam_b = BASE_GOALS * np.exp(-diff / RATING_SCALE)
    return lam_a, lam_b


def play_match(team_a, rating_a, team_b, rating_b):
    """Simulate a single knockout match (extra time / penalties on a draw)."""
    lam_a, lam_b = expected_goals(rating_a, rating_b)
    goals_a = RNG.poisson(lam_a)
    goals_b = RNG.poisson(lam_b)

    if goals_a > goals_b:
        return team_a, rating_a
    if goals_b > goals_a:
        return team_b, rating_b

    # Draw -> extra time / penalties: higher-rated team slightly favoured,
    # but still essentially a coin flip (penalties are high-variance)
    p_a_wins = 0.5 + 0.5 * np.tanh((rating_a - rating_b) / 800.0)
    if RNG.random() < p_a_wins:
        return team_a, rating_a
    return team_b, rating_b


def seed_bracket(df):
    """
    Standard 1-vs-32, 2-vs-31 ... seeding so the highest-rated teams
    are kept apart for as long as possible, like real World Cup seeding.
    """
    n = len(df)
    order = []
    i, j = 0, n - 1
    while i < j:
        order.append(i)
        order.append(j)
        i += 1
        j -= 1
    return df.iloc[order].reset_index(drop=True)


def simulate_tournament(df):
    """Simulate one full single-elimination bracket, return the champion."""
    teams = list(df["team"])
    ratings = list(df["rating"])

    while len(teams) > 1:
        next_teams, next_ratings = [], []
        for k in range(0, len(teams), 2):
            winner, w_rating = play_match(teams[k], ratings[k], teams[k + 1], ratings[k + 1])
            next_teams.append(winner)
            next_ratings.append(w_rating)
        teams, ratings = next_teams, next_ratings

    return teams[0]


def run_monte_carlo(df, n_sims=N_SIMULATIONS):
    bracket = seed_bracket(df)
    champion_counts = {team: 0 for team in df["team"]}

    for _ in range(n_sims):
        champ = simulate_tournament(bracket)
        champion_counts[champ] += 1

    results = pd.DataFrame({
        "team": list(champion_counts.keys()),
        "wins": list(champion_counts.values()),
    })
    results["win_probability_%"] = 100 * results["wins"] / n_sims
    results = results.sort_values("win_probability_%", ascending=False).reset_index(drop=True)
    return results


def plot_top_contenders(results, top_n=10, out_path="results/win_probabilities.png"):
    top = results.head(top_n).iloc[::-1]  # reverse for horizontal bar chart order

    fig, ax = plt.subplots(figsize=(8, 6))
    bars = ax.barh(top["team"], top["win_probability_%"], color="#1f77b4")
    ax.bar_label(bars, fmt="%.1f%%", padding=4, fontsize=9)
    ax.set_xlabel("Predicted Win Probability (%)")
    ax.set_title(f"FIFA World Cup Winner Prediction\n(Monte Carlo, {N_SIMULATIONS:,} simulated brackets)")
    ax.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=160)
    print(f"Saved {out_path}")


if __name__ == "__main__":
    teams_df = load_teams()
    results = run_monte_carlo(teams_df)

    print("\nTop 10 Predicted World Cup Winners:")
    print(results.head(10).to_string(index=False))

    plot_top_contenders(results)
    results.to_csv("results/win_probabilities.csv", index=False)
    print("\nSaved results/win_probabilities.csv")
